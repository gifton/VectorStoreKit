// VectorStoreKit: Phase 2 Performance Benchmarks
//
// Comprehensive benchmark suite for Phase 2 performance optimizations
// Tests Metal acceleration, CPU/GPU selection, and unified buffer management

import Foundation
import Metal
import Accelerate
import os.log

/// Comprehensive benchmark suite for Phase 2 optimizations
public actor Phase2PerformanceBenchmarks {
    
    private let logger = Logger(subsystem: "VectorStoreKit", category: "Phase2Benchmarks")
    private let accelerationEngine: MetalAccelerationEngine
    private let reporter: BenchmarkReporter
    
    // Benchmark configurations
    private let dimensions = [128, 256, 512, 768, 1024, 1536, 2048]
    private let batchSizes = [100, 1000, 10_000, 100_000]
    private let iterations = 10
    
    public init() async throws {
        self.accelerationEngine = MetalAccelerationEngine.shared
        self.reporter = BenchmarkReporter()
        
        logger.info("Initialized Phase 2 Performance Benchmarks")
    }
    
    // MARK: - Main Benchmark Suite
    
    /// Run complete Phase 2 benchmark suite
    public func runCompleteSuite() async throws -> BenchmarkReport {
        logger.info("Starting Phase 2 Performance Benchmark Suite")
        
        var results = BenchmarkReport(suiteName: "Phase 2 Performance")
        
        // 1. Metal Acceleration Benchmarks
        results.sections.append(try await benchmarkMetalAcceleration())
        
        // 2. CPU vs GPU Decision Making
        results.sections.append(try await benchmarkCPUGPUDecision())
        
        // 3. Unified Buffer Management
        results.sections.append(try await benchmarkBufferManagement())
        
        // 4. Shader Compilation Performance
        results.sections.append(try await benchmarkShaderCompilation())
        
        // 5. End-to-End Distance Computation
        results.sections.append(try await benchmarkEndToEndDistance())
        
        // 6. Quantization Performance
        results.sections.append(try await benchmarkQuantization())
        
        // 7. Matrix Operations
        results.sections.append(try await benchmarkMatrixOperations())
        
        // Generate summary
        results.summary = generateSummary(from: results)
        
        // Save report
        try await reporter.saveReport(results)
        
        return results
    }
    
    // MARK: - Individual Benchmarks
    
    /// Benchmark Metal acceleration across different workloads
    private func benchmarkMetalAcceleration() async throws -> BenchmarkSection {
        var section = BenchmarkSection(name: "Metal Acceleration")
        logger.info("Benchmarking Metal acceleration...")
        
        for dimension in dimensions {
            for batchSize in batchSizes {
                let workloadName = "Metal_D\(dimension)_B\(batchSize)"
                
                // Generate test data
                let vectors = generateTestVectors(count: batchSize, dimension: dimension)
                let query = vectors[0]
                
                // Benchmark GPU path
                let gpuResult = try await measurePerformance(name: "\(workloadName)_GPU") {
                    _ = try await self.accelerationEngine.computeDistances(
                        query: query,
                        candidates: vectors,
                        metric: .euclidean
                    )
                }
                
                section.results.append(gpuResult)
            }
        }
        
        return section
    }
    
    /// Benchmark CPU/GPU decision making
    private func benchmarkCPUGPUDecision() async throws -> BenchmarkSection {
        var section = BenchmarkSection(name: "CPU/GPU Decision Making")
        logger.info("Benchmarking CPU/GPU decision making...")
        
        // Test decision making at various thresholds
        let testSizes = [10, 50, 100, 500, 1000, 5000, 10_000, 50_000]
        
        for size in testSizes {
            let vectors = generateTestVectors(count: size, dimension: 512)
            let query = vectors[0]
            
            let result = try await measurePerformance(name: "Decision_Size\(size)") {
                _ = try await self.accelerationEngine.computeDistances(
                    query: query,
                    candidates: vectors,
                    metric: .cosine
                )
            }
            
            // Track which path was chosen
            let stats = await accelerationEngine.getPerformanceStatistics()
            result.metadata["executionPath"] = stats.performanceStatistics.operationCounts.keys.first ?? "unknown"
            
            section.results.append(result)
        }
        
        return section
    }
    
    /// Benchmark unified buffer management
    private func benchmarkBufferManagement() async throws -> BenchmarkSection {
        var section = BenchmarkSection(name: "Unified Buffer Management")
        logger.info("Benchmarking buffer management...")
        
        // Test buffer allocation and reuse patterns
        let bufferSizes = [1024, 4096, 16384, 65536, 262144] // 1KB to 256KB
        let allocationCounts = [10, 100, 1000]
        
        for size in bufferSizes {
            for count in allocationCounts {
                let result = try await measurePerformance(name: "Buffer_S\(size)_C\(count)") {
                    // Simulate buffer allocation patterns
                    for _ in 0..<count {
                        let data = [Float](repeating: 0.0, count: size / MemoryLayout<Float>.size)
                        _ = try await self.accelerationEngine.computeDistances(
                            query: SIMD32<Float>(repeating: 0.0),
                            candidates: [SIMD32<Float>(repeating: 1.0)],
                            metric: .euclidean
                        )
                    }
                }
                
                // Get buffer pool statistics
                let stats = await accelerationEngine.getPerformanceStatistics()
                result.metadata["bufferReuseRate"] = "\(stats.bufferStatistics.hitRate)"
                
                section.results.append(result)
            }
        }
        
        return section
    }
    
    /// Benchmark shader compilation and caching
    private func benchmarkShaderCompilation() async throws -> BenchmarkSection {
        var section = BenchmarkSection(name: "Shader Compilation")
        logger.info("Benchmarking shader compilation...")
        
        // Clear shader cache first
        let device = try MetalDevice()
        let pipelineManager = try MetalPipelineManager(device: device)
        await pipelineManager.clearCache()
        
        // Benchmark cold compilation
        let coldResult = try await measurePerformance(name: "ShaderCompilation_Cold") {
            await pipelineManager.precompileStandardPipelines()
        }
        section.results.append(coldResult)
        
        // Benchmark warm access
        let warmResult = try await measurePerformance(name: "ShaderCompilation_Warm") {
            for _ in 0..<100 {
                _ = try await pipelineManager.getPipeline(for: .euclideanDistance)
            }
        }
        section.results.append(warmResult)
        
        // Get cache statistics
        let cacheStats = await pipelineManager.cacheStatistics
        section.metadata["cachedPipelines"] = "\(cacheStats.cachedPipelines)"
        section.metadata["diskCacheSize"] = "\(cacheStats.diskCacheSize)"
        
        return section
    }
    
    /// Benchmark end-to-end distance computation
    private func benchmarkEndToEndDistance() async throws -> BenchmarkSection {
        var section = BenchmarkSection(name: "End-to-End Distance Computation")
        logger.info("Benchmarking end-to-end distance computation...")
        
        let metrics: [DistanceMetric] = [.euclidean, .cosine, .manhattan, .dotProduct]
        
        for metric in metrics {
            for dimension in [128, 512, 1024] {
                for batchSize in [1000, 10_000] {
                    let vectors = generateTestVectors(count: batchSize, dimension: dimension)
                    let queries = Array(vectors.prefix(10))
                    
                    let result = try await measurePerformance(
                        name: "\(metric)_D\(dimension)_B\(batchSize)"
                    ) {
                        _ = try await self.accelerationEngine.batchComputeDistances(
                            queries: queries,
                            candidates: vectors,
                            metric: metric,
                            topK: 10
                        )
                    }
                    
                    // Calculate throughput
                    let totalComparisons = queries.count * vectors.count
                    result.metadata["throughput"] = "\(Double(totalComparisons) / result.duration) comparisons/sec"
                    
                    section.results.append(result)
                }
            }
        }
        
        return section
    }
    
    /// Benchmark quantization operations
    private func benchmarkQuantization() async throws -> BenchmarkSection {
        var section = BenchmarkSection(name: "Quantization Performance")
        logger.info("Benchmarking quantization...")
        
        let schemes: [QuantizationScheme] = [.product, .scalar]
        
        for scheme in schemes {
            for dimension in [256, 512, 1024] {
                let vectors = generateTestVectors(count: 10_000, dimension: dimension)
                
                let parameters = QuantizationParameters(
                    scheme: scheme,
                    numberOfClusters: scheme == .product ? 256 : 0,
                    numberOfSubvectors: scheme == .product ? dimension / 4 : 0,
                    scalarRange: scheme == .scalar ? (-1.0, 1.0) : nil
                )
                
                let result = try await measurePerformance(
                    name: "\(scheme)_D\(dimension)"
                ) {
                    _ = try await self.accelerationEngine.quantizeVectors(
                        vectors: vectors,
                        scheme: scheme,
                        parameters: parameters
                    )
                }
                
                section.results.append(result)
            }
        }
        
        return section
    }
    
    /// Benchmark matrix operations
    private func benchmarkMatrixOperations() async throws -> BenchmarkSection {
        var section = BenchmarkSection(name: "Matrix Operations")
        logger.info("Benchmarking matrix operations...")
        
        let matrixSizes = [(64, 64), (256, 256), (512, 512), (1024, 1024)]
        
        for (rows, cols) in matrixSizes {
            let matrixA = generateMatrix(rows: rows, cols: cols)
            let matrixB = generateMatrix(rows: cols, cols: rows)
            
            let result = try await measurePerformance(
                name: "MatMul_\(rows)x\(cols)"
            ) {
                _ = try await self.accelerationEngine.matrixMultiply(
                    matrixA: matrixA,
                    matrixB: matrixB
                )
            }
            
            // Calculate GFLOPS
            let operations = 2.0 * Double(rows) * Double(cols) * Double(cols)
            let gflops = operations / result.duration / 1e9
            result.metadata["GFLOPS"] = String(format: "%.2f", gflops)
            
            section.results.append(result)
        }
        
        return section
    }
    
    // MARK: - Helper Methods
    
    private func measurePerformance(
        name: String,
        operation: () async throws -> Void
    ) async throws -> BenchmarkResult {
        var durations: [TimeInterval] = []
        var memoryBefore = 0
        var memoryAfter = 0
        
        // Warm-up
        try await operation()
        
        // Measure
        for _ in 0..<iterations {
            memoryBefore = getCurrentMemoryUsage()
            
            let start = CFAbsoluteTimeGetCurrent()
            try await operation()
            let duration = CFAbsoluteTimeGetCurrent() - start
            
            memoryAfter = getCurrentMemoryUsage()
            durations.append(duration)
        }
        
        let sortedDurations = durations.sorted()
        
        return Phase2BenchmarkResult(
            name: name,
            duration: sortedDurations[sortedDurations.count / 2], // median
            iterations: iterations,
            memoryDelta: memoryAfter - memoryBefore,
            metadata: [:]
        )
    }
    
    private func generateTestVectors(count: Int, dimension: Int) -> [SIMD32<Float>] {
        // Generate random vectors for testing
        var vectors: [SIMD32<Float>] = []
        
        for _ in 0..<count {
            var values = [Float](repeating: 0, count: 32)
            for i in 0..<min(32, dimension) {
                values[i] = Float.random(in: -1...1)
            }
            vectors.append(SIMD32<Float>(values))
        }
        
        return vectors
    }
    
    private func generateMatrix(rows: Int, cols: Int) -> [[Float]] {
        (0..<rows).map { _ in
            (0..<cols).map { _ in Float.random(in: -1...1) }
        }
    }
    
    private func getCurrentMemoryUsage() -> Int {
        var info = mach_task_basic_info()
        var count = mach_msg_type_number_t(MemoryLayout<mach_task_basic_info>.size) / 4
        
        let result = withUnsafeMutablePointer(to: &info) {
            $0.withMemoryRebound(to: integer_t.self, capacity: 1) {
                task_info(
                    mach_task_self_,
                    task_flavor_t(MACH_TASK_BASIC_INFO),
                    $0,
                    &count
                )
            }
        }
        
        return result == KERN_SUCCESS ? Int(info.resident_size) : 0
    }
    
    private func generateSummary(from report: BenchmarkReport) -> String {
        var summary = """
        Phase 2 Performance Benchmark Summary
        =====================================
        
        """
        
        for section in report.sections {
            summary += "\n\(section.name):\n"
            
            // Find best and worst performing
            let sorted = section.results.sorted { $0.duration < $1.duration }
            if let best = sorted.first, let worst = sorted.last {
                summary += "  Best: \(best.name) - \(String(format: "%.3f", best.duration * 1000))ms\n"
                summary += "  Worst: \(worst.name) - \(String(format: "%.3f", worst.duration * 1000))ms\n"
            }
            
            // Average performance
            let avgDuration = section.results.map { $0.duration }.reduce(0, +) / Double(section.results.count)
            summary += "  Average: \(String(format: "%.3f", avgDuration * 1000))ms\n"
        }
        
        return summary
    }
}

// MARK: - Supporting Types

public struct BenchmarkReport: Codable {
    let suiteName: String
    var sections: [BenchmarkSection] = []
    var summary: String = ""
    let timestamp = Date()
}

public struct BenchmarkSection: Codable {
    let name: String
    var results: [Phase2BenchmarkResult]
    var metadata: [String: String]
    
    public init(name: String, results: [Phase2BenchmarkResult] = [], metadata: [String: String] = [:]) {
        self.name = name
        self.results = results
        self.metadata = metadata
    }
}

public struct Phase2BenchmarkResult: Codable {
    let name: String
    let duration: TimeInterval
    let iterations: Int
    let memoryDelta: Int
    var metadata: [String: String]
}

/// Simple benchmark reporter
public actor BenchmarkReporter {
    private let fileManager = FileManager.default
    private let benchmarkDirectory: URL
    
    public init() {
        let documentsPath = fileManager.urls(for: .documentDirectory, in: .userDomainMask).first!
        self.benchmarkDirectory = documentsPath.appendingPathComponent("VectorStoreKit/Benchmarks")
        
        try? fileManager.createDirectory(at: benchmarkDirectory, withIntermediateDirectories: true)
    }
    
    public func saveReport(_ report: BenchmarkReport) async throws {
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        encoder.dateEncodingStrategy = .iso8601
        
        let data = try encoder.encode(report)
        
        let filename = "benchmark_\(report.suiteName.replacingOccurrences(of: " ", with: "_"))_\(Date().timeIntervalSince1970).json"
        let fileURL = benchmarkDirectory.appendingPathComponent(filename)
        
        try data.write(to: fileURL)
        
        // Also save summary as text
        let summaryURL = fileURL.deletingPathExtension().appendingPathExtension("txt")
        try report.summary.write(to: summaryURL, atomically: true, encoding: .utf8)
    }
}