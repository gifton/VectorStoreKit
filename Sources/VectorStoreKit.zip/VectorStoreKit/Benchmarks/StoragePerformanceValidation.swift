import Foundation
import VectorStoreKit

/// Simple performance validation for the 3-tier storage system
@main
struct StoragePerformanceValidation {
    static func main() async throws {
        print("=== VectorStoreKit 3-Tier Storage Performance Validation ===\n")
        
        // Configuration
        let config = ThreeTierStorageConfiguration(
            memoryLimit: 100 * 1024 * 1024, // 100MB
            ssdPath: "/tmp/vectorstore-ssd",
            archivePath: "/tmp/vectorstore-archive",
            autoMigrationEnabled: true
        )
        
        // Create storage
        let storage = try await ThreeTierStorage(configuration: config)
        
        // Test data sizes
        let testSizes = [
            ("Small (1KB)", 1024),
            ("Medium (100KB)", 100 * 1024),
            ("Large (1MB)", 1024 * 1024)
        ]
        
        // Performance tests
        for (sizeName, size) in testSizes {
            print("Testing \(sizeName) vectors...")
            
            // Generate test data
            let data = Data(repeating: 42, count: size)
            let numOperations = 100
            
            // Measure store performance
            let storeStart = Date()
            for i in 0..<numOperations {
                try await storage.store(
                    key: "test-\(size)-\(i)",
                    data: data,
                    options: StorageOptions(priority: .normal)
                )
            }
            let storeTime = Date().timeIntervalSince(storeStart)
            let storeOpsPerSec = Double(numOperations) / storeTime
            
            // Measure retrieve performance
            let retrieveStart = Date()
            for i in 0..<numOperations {
                _ = try await storage.retrieve(key: "test-\(size)-\(i)")
            }
            let retrieveTime = Date().timeIntervalSince(retrieveStart)
            let retrieveOpsPerSec = Double(numOperations) / retrieveTime
            
            // Get statistics
            let stats = await storage.statistics()
            
            print("  Store: \(String(format: "%.0f", storeOpsPerSec)) ops/sec")
            print("  Retrieve: \(String(format: "%.0f", retrieveOpsPerSec)) ops/sec")
            print("  Memory tier: \(stats.tierItemCounts[.memory] ?? 0) items")
            print("  SSD tier: \(stats.tierItemCounts[.ssd] ?? 0) items")
            print("  Archive tier: \(stats.tierItemCounts[.archive] ?? 0) items")
            print("  Compression ratio: \(String(format: "%.2f", stats.compressionRatio))x\n")
            
            // Cleanup
            for i in 0..<numOperations {
                try await storage.delete(key: "test-\(size)-\(i)")
            }
        }
        
        // Test automatic migration
        print("Testing automatic tier migration...")
        
        // Fill memory tier
        let largeData = Data(repeating: 42, count: 1024 * 1024) // 1MB
        for i in 0..<120 { // Exceed memory limit
            try await storage.store(
                key: "migration-test-\(i)",
                data: largeData,
                options: StorageOptions(priority: .normal)
            )
        }
        
        // Wait for migration
        try await Task.sleep(nanoseconds: 2_000_000_000) // 2 seconds
        
        let finalStats = await storage.statistics()
        print("After migration:")
        print("  Memory tier: \(finalStats.tierItemCounts[.memory] ?? 0) items")
        print("  SSD tier: \(finalStats.tierItemCounts[.ssd] ?? 0) items")
        print("  Archive tier: \(finalStats.tierItemCounts[.archive] ?? 0) items")
        print("  Total compression: \(String(format: "%.2f", finalStats.compressionRatio))x")
        
        print("\n✅ 3-Tier Storage Performance Validation Complete")
    }
}